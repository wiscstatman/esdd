/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 197635
#define R_NICK "Kite-Eating Tree"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "4.3"
#define R_STATUS ""
#define R_YEAR   "2017"
#define R_MONTH  "11"
#define R_DAY    "30"
#define R_SVN_REVISION 73796
#define R_FILEVERSION    3,43,73796,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
